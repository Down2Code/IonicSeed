angular
    .module('comicsApp')
    .controller('ComicsController', function(Comics, $scope, $ionicLoading) {
        var _this = this;
          _this.comics=[ ];
        $scope.$on('$ionicView.enter', function(){
            $ionicLoading.show();

            Comics.getComics().then(function(response){
                _this.comics = response.data;
            }).catch(function(response){
                //request was not successful
                //handle the error
            }).finally(function(){
                $ionicLoading.hide();
            });
        });
    })

    .controller('ComicDetailController', function(Comics, $stateParams, $scope, $ionicLoading) {
        var _this = this;
        _this.comic=[ ];
        $scope.$on('$ionicView.enter', function(){
            $ionicLoading.show();

            Comics.getComic($stateParams.comicId).then(function(response){
                _this.comic = response.data;
            }).catch(function(response){
                //request was not successful
                //handle the error
            }).finally(function(){
                $ionicLoading.hide();
            });
        });
    })
    .controller('ComicDetailControllerLevel1', function( $stateParams, $scope, $ionicLoading,$log) {
        var _this = this;
        _this.comic1=[ ];
        $scope.$on('$ionicView.enter', function(){
            $ionicLoading.show();
            _this.comic1=JSON.parse($stateParams.data);
            $log.info(_this.comic1);
             $ionicLoading.hide();
            //Comics.getComic($stateParams.comicId).then(function(response){
              //  _this.comic1 = response.data;
            //}).catch(function(response){
                //request was not successful
                //handle the error
            //}).finally(function(){
              //  $ionicLoading.hide();
            //});
        });
    });