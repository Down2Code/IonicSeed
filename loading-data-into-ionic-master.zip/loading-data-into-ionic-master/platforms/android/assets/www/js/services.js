angular
    .module('comicsApp')
    .factory('Comics', function($http) {
        var dataSource = 'https://test-b06a7.firebaseio.com/SiteDetails/Sites.json';
        var detailedDataSource='https://test-b06a7.firebaseio.com/SiteDetails/Sites';
        return {
            getComics: function() {
                return $http.get(dataSource);
            },
            getComic: function(comicId) {
                return $http.get(detailedDataSource+'/'+comicId+'/Description'+'.json');
            }
        }
    });